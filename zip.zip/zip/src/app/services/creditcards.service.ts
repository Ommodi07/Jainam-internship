import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CreditCard } from '../models/credit-card';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CreditcardsService {
  private apiUrl = 'http://localhost:4201/credentials';
  constructor(private httpClient: HttpClient) {}

  // create new card
  createCreditCard(creditCard: CreditCard): Observable<CreditCard> {
    return this.httpClient.post<CreditCard>(this.apiUrl, creditCard);
  }

  // get all cards
  getCreditCards() : Observable<CreditCard[]> {
    return this.httpClient.get<CreditCard[]>(this.apiUrl);
  }

  // get specific card
  getCreditCardById(id : Number) : Observable<CreditCard> {
    const url = `${this.apiUrl}/${id}`;
    return this.httpClient.get<CreditCard>(url);
  }

  // update functionality

  updateCreditCard(creditCard : CreditCard) : Observable<CreditCard> {
    const url = `${this.apiUrl}/${creditCard.id}`;
    return this.httpClient.put<CreditCard>(url,creditCard);
  }

  // delete fun
  deleteCreditCard(id : Number): Observable<void> {
    const url = `${this.apiUrl}/${id}`;
    return this.httpClient.delete<void>(url);
  }
}
