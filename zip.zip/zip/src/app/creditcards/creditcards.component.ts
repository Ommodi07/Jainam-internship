import { Component, ViewChild } from '@angular/core';
import { CreditCard } from '../models/credit-card';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { CreditcardsService } from '../services/creditcards.service';

@Component({
  selector: 'app-creditcards',
  templateUrl: './creditcards.component.html',
  styleUrls: ['./creditcards.component.scss']
})
export class CreditcardsComponent {

  creditcards: CreditCard[] = [];

  constructor(private creditcardservice : CreditcardsService) {
    this.creditcardservice.getCreditCards().subscribe((data:CreditCard[]) => { //subscribe is used for observable
      console.log(data);
      this.creditcards = data;
      // this.creditcards = data.sort((a,b) => a.id - b.id); // Applied Sorting for better visualization
      this.dataSource = new MatTableDataSource(this.creditcards);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }
  dataSource = new MatTableDataSource(this.creditcards);
  displayColumns = ["select", "id", "cardName", "description", "bankName", "maxCredit", "interestRate", "active", "recommendedCreditScore", "actions"];

  selection = new SelectionModel(true, []);

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  selectHandler(row: CreditCard) {
    this.selection.toggle(row as never);
  }
}
