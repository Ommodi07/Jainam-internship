import { Component } from '@angular/core';
import { CreditCard } from '../../models/credit-card';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.scss']
})
export class AddComponent {

  newCreditCard : CreditCard = {
    id : undefined,
    cardName : "",
    bankName : "",
    description : "",
    maxCredit : 50000,
    interestRate : 9,
    annualFee : 12,
    active : true,
    introOffer: 0,
    recommendedCreditScore : "100-500",
    numberOfApplications : 4,
    termsAndConditions : "Terms and conditions for the credit card.",
    createdDate : Date()
  }

  saveCreditCard() {
    console.log("submitted")
  }
}
